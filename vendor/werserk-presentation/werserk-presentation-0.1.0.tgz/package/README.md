# werserk-presentation

Приватный инструментарий для создания и демонстрации HTML-презентаций на Reveal.js. Доклады живут в отдельных проектах. Здесь находятся CLI, runtime, шаблон и синтетические проверки.

Node 22+, npm. Для браузерных проверок/PDF нужен Chromium: `CHROMIUM_PATH=/path/to/chrome`; на текущем Linux по умолчанию `/usr/bin/google-chrome-stable`.

```sh
npm ci
npm run new -- ../my-presentation 'git+https://github.com/werserk/werserk-presentation.git#<reviewed-commit>'
cd ../my-presentation
npm install
npm run dev
```

Git должен иметь доступ к приватному репозиторию. После первой установки сохраните `package-lock.json`; следующие установки — `npm ci`. Точный commit и lock фиксируют toolkit и зависимости. Аргумент dependency обязателен. Шаблон создаёт проектный `.npmrc` с `allow-git=root`: npm 12 по умолчанию запрещает Git-зависимости; разрешены только прямые зависимости этого проекта, глобальные настройки не меняются. Для разработки можно явно передать file:/path/to/toolkit или путь к проверенному tgz; такой источник проверяется отдельно от приватного Git.

- `npm run dev` собирает проект и запускает HTTP только на 127.0.0.1:4173. После редактирования повторите сборку и перезагрузите страницу.
- `npm run build` создаёт `dist/` в проекте доклада.
- `npm run check` проверяет локальные ресурсы; `npm run check -- --browser` проходит слайды при заблокированных внешних запросах.
- `npm run export` создаёт полный `dist/presentation.pdf`.
- `npm run pack` создаёт `presentation-offline.tar.gz`: распаковать, выполнить `node serve.mjs`, открыть адрес. Установленный toolkit, npm и Codex для показа не нужны; Node остаётся необходим.

Окно аудитории: `index.html`. Нажмите «Спикер» для синхронного отдельного окна с речью, превью, таймером и указкой. `reader.html` показывает всё сразу; `speaker-notes.md` содержит полный текст и резерв.

[Разметка](docs/authoring.md) · [Показ](docs/presenting.md) · [Карта и причины решений](docs/architecture.md) · [Фактические проверки и ограничения](docs/process.md)

Для работы над toolkit: `npm test`, `npm run package:check`. Проверки используют маленькую вымышленную презентацию; реальные доклады сюда не добавляются. Публикация в npm, GitHub Pages и публичный сервер не настроены.
