# Разметка и сборка

Источник — HTML отдельного проекта. CLI читает `presentation.config.json` (необязательно): `id`, `input` (по умолчанию slides.html), `out` (dist). Проект может сначала подготовить HTML своим скриптом: расчёты, данные и предметные проверки остаются в докладе.

```html
<article id="intro" class="sheet" aria-label="Исследовательская проблема">
  <h1>Название</h1>
  <p data-step="2">Исходный факт</p>
  <aside data-step="1">Нужное определение</aside>
  <p data-step="3">Вопрос, который следует из факта</p>
  <template class="speaker-notes">
    <p data-note-step="0">Представляем работу.</p>
    <p data-note-step="1">Объясняем определение.</p>
    <p data-note-step="2">Указываем на факт и поясняем его.</p>
    <p data-note-step="3">Формулируем исследовательский вопрос.</p>
    <p data-reserve>Подробность для обсуждения.</p>
  </template>
</article>
```

Порядок шагов задаётся числами, независимо от положения в DOM. Несколько элементов одного шага появляются одновременно. Последовательность 1..N без пропусков; для открытия и каждого шага обязательна речь. Все её абзацы должны иметь шаг либо принадлежать резерву: неразмеченный текст вызывает ошибку вместо молчаливой потери. Скрытые элементы сохраняют геометрию, исключены из фокуса.

Необязательный пример: `<article id="example" class="sheet" data-optional data-parent="intro">`. Родитель — существующий основной слайд. Ссылка `href="#example"` открывает ветку, `href="#intro"` возвращает, ссылка на следующий основной продолжает доклад. Пример не входит в основной счётчик. Вход с родителя сохраняет его точный шаг; прямой вход без истории возвращает к полностью раскрытому родителю.

CSS и изображения — локальные ссылки внутри проекта. Сборка копирует ссылки из head, img и CSS url(), переписывает пути и сохраняет ресурсы рядом с viewer. Удалённые ресурсы и srcset сейчас отклоняются. Внешние ссылки на источники остаются ссылками; материалы не загружаются автоматически. Интерактивные формы/скрипты авторского HTML не подключаются автоматически: runtime общий, композиции собственные.

Для оригинального рисунка используйте `button.figure-open[data-figure="figure-id"]`, соответствующий `dialog#figure-id`, кнопку `.figure-close`. Без data-figure используется figure-dialog. Пока открыт рисунок, шаги заблокированы; Escape закрывает его и возвращает фокус. Диалоги показаны только по запросу, не входят в PDF; нужный фрагмент рисунка должен быть на слайде.

Компоновка остаётся собственной: .sheet задаёт размеры/поля/типографику, runtime масштабирует всю сцену. data-page-width/data-page-height на html задают сцену, по умолчанию 1280×720. Светлая/тёмная тема — data-theme на html; тема доклада определяет её CSS. Градиенты не используются.

Полный reader и PDF происходят из тех же .sheet: один физический слайд — одна страница, включая примеры; шаги в печати раскрыты. Markdown речи содержит открытие, шаги и резерв. Редактируйте источники, а не dist.

Output paths must be inside the external project and separate from authored inputs. Existing build directories can be replaced only with the toolkit ownership marker; existing archives only when their toolkit sidecar matches their digest. Keep generated outputs/markers ignored. Reader includes TOC, speech/reserve details and working original-figure dialogs; reading controls do not use Reveal state and do not add PDF pages.

Authored semantic section tags are supported, including a section.sheet root. The compiler reserves presentation-section for audience output; do not use that tag in source. Reader keeps original tags. Standard author CSS type selectors are rewritten with the same specificity and type grouping; vendor Reveal/runtime selectors are unchanged.
