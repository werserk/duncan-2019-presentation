import {load} from 'cheerio';
import postcss from 'postcss';
import selectorParser from 'postcss-selector-parser';

const alias='presentation-section';
const replacement=selectorParser().astSync(`:is(section:where(.reader *),${alias})`).first.first;

export function authoredCSS(text){
 const css=postcss.parse(text);
 css.walkRules(rule=>{
  rule.selector=selectorParser(root=>{
   const tags=[];root.walkTags(tag=>{if(tag.value.toLowerCase()==='section'&&!tag.namespace)tags.push(tag);});
   for(const tag of tags)tag.replaceWith(replacement.clone());
  }).processSync(rule.selector);
 });
 return css.toString();
}

export function revealSheet(html){
 const $=load(html,null,false);
 if($(alias).length)throw Error(`${alias} is reserved for compiled output`);
 $('section').each((_,el)=>{
  el.name=alias;
  const node=$(el);
  if(!node.attr('role')&&['aria-label','aria-labelledby','title'].some(name=>node.attr(name)))node.attr('role','region');
 });
 return $.html();
}
