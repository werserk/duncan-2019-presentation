import {readFile,writeFile,cp,mkdir,rm,mkdtemp} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {chromium} from 'playwright';
import {serve} from './server.js';
import {toolkitRoot} from './build.js';
import {outputBoundary} from './paths.js';
const exec=promisify(execFile);
export async function check(out,{browser=false}={}) {
 const config=(await import(pathToFileURL(path.resolve(out,'config.js')).href+'?check='+Date.now())).default;
 const manifest=JSON.parse(await readFile(path.join(out,'asset-manifest.json'),'utf8'));
 for(const filename of manifest.assets)await readFile(path.join(out,'assets',filename));
 let result={slides:config.slides.length,core:config.slides.filter(s=>!s.parent).length,resources:manifest.assets.length};
 if(browser) {
  const {server,url}=await serve(out);let instance;
  try {
   instance=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/google-chrome-stable'});
   const page=await instance.newPage({viewport:{width:1600,height:900}}),errors=[],external=[];
   page.on('pageerror',e=>errors.push(e.message));
   await page.route('**/*',route=>{if(!route.request().url().startsWith(url)) {external.push(route.request().url());return route.abort();}return route.continue();});
   await page.goto(url);await page.waitForFunction(()=>window.presentation);
   for(const slide of config.slides) {
    await page.evaluate(id=>window.presentation.command('goto',id),slide.id);
    async function confirmed(step){
     const actual=await page.evaluate(()=>({state:window.presentation.state(),native:window.presentation.reveal.getCurrentSlide()?.id,fragments:[...document.querySelectorAll('.slides>section.present .fragment')].map(el=>({index:Number(el.dataset.fragmentIndex),visible:el.classList.contains('visible')}))}));
     if(actual.state.id!==slide.id||actual.state.step!==step||actual.native!=='page-'+slide.id||actual.fragments.some(f=>f.visible!==(f.index<step)))throw Error(`Playback mismatch ${slide.id} step ${step}: ${JSON.stringify(actual)}`);
    }
    await confirmed(0);
    for(let i=1;i<=slide.steps;i++){await page.evaluate(()=>window.presentation.command('next'));await confirmed(i);}
    for(let i=slide.steps-1;i>=0;i--){await page.evaluate(()=>window.presentation.command('back'));await confirmed(i);}
   }
   await page.goto(url+'/reader.html');await page.locator('.sheet').last().waitFor();
   if(errors.length||external.length)throw Error(JSON.stringify({errors,external}));
   result={...result,browser:'pass',externalRequests:external.length};
  }finally {await instance?.close();await new Promise(r=>server.close(r));}
 }
 return result;
}
export async function exportPDF(out,root=path.dirname(path.resolve(out))) {
 out=await outputBoundary({root,target:out});
 const {server,url}=await serve(out);let browser;
 try {
  browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/google-chrome-stable'});
  const page=await browser.newPage();await page.goto(url+'/reader.html');
  await page.evaluate(()=>document.fonts.ready);
  await page.pdf({path:path.join(out,'presentation.pdf'),printBackground:true,preferCSSPageSize:true});
  return path.join(out,'presentation.pdf');
 }finally {await browser?.close();await new Promise(r=>server.close(r));}
}
export async function pack(out,target,root=path.dirname(path.resolve(out))) {
 out=await outputBoundary({root,target:out});
 target=await outputBoundary({root,target,kind:'file',protectedPaths:[out]});
 const sidecar=target+'.presentation-output.json';
 try{await readFile(sidecar);await readFile(target);}catch(e){if(e.code!=='ENOENT')throw e;try{await readFile(sidecar);throw Error('Archive metadata collides with existing file');}catch(error){if(error.code!=='ENOENT')throw error;}}
 const staging=await mkdtemp(path.join(root,'.presentation-package-'));
 try {await cp(out,staging,{recursive:true});
 // The delivered viewer runs from Node alone, without toolkit/node_modules/Codex.
 const server=await readFile(path.join(toolkitRoot,'tools/server.js'),'utf8');
 await writeFile(path.join(staging,'serve.mjs'),server+'\nimport {fileURLToPath} from "node:url";\nconst running=await serve(fileURLToPath(new URL(".",import.meta.url)),Number(process.argv[2]||4173));console.log(running.url);\n');
 await writeFile(path.join(staging,'START.txt'),'Node 22+\nnode serve.mjs\nOpen http://127.0.0.1:4173\nSpeaker: click Presenter; move audience window to the extended display.\nReader: /reader.html; notes: speaker-notes.md\nStop: Ctrl+C\n');
 await mkdir(path.dirname(target),{recursive:true});
 await exec('tar',['-czf',target,'-C',staging,'.']);
 await writeFile(sidecar,JSON.stringify({generator:'werserk-presentation',sha256:createHash('sha256').update(await readFile(target)).digest('hex')}));
 await rm(staging,{recursive:true,force:true});
 return target;
 }finally{await rm(staging,{recursive:true,force:true});}
}
