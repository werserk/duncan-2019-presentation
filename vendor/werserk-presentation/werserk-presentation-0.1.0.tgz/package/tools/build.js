import {readFile,writeFile,mkdir,cp,rm,rename,realpath,readdir,mkdtemp} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {load} from 'cheerio';
import {authoredCSS,revealSheet} from './sections.js';
const require=createRequire(import.meta.url);
import {toolkitRoot,outputBoundary,inside} from './paths.js';
export {toolkitRoot} from './paths.js';
const hash=text=>createHash('sha256').update(text).digest('hex');
const escape=text=>String(text).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');

export async function build({root=process.cwd(),input='slides.html',out='dist',id,licences=[]}={}) {
 root=await realpath(root);
 const sourcePath=await realpath(path.resolve(root,input));
 const output=await outputBoundary({root,target:path.resolve(root,out),protectedPaths:[sourcePath]});
 if (!inside(root,sourcePath)) throw Error('Input/output must be separate paths inside presentation project');
 const html=await readFile(sourcePath,'utf8'),$=load(html);
 if($('presentation-section').length)throw Error('presentation-section is reserved for compiled output');
 const title=$('title').text()||'Presentation';
 const width=Number($('html').attr('data-page-width')||1280),height=Number($('html').attr('data-page-height')||720);
 if(!Number.isFinite(width)||!Number.isFinite(height)||width<1||height<1)throw Error('Invalid slide dimensions');
 const slides=[],seen=new Set();
 $('.sheet').each((_,el)=>{
  const slide=$(el),sid=slide.attr('id');
  if(!sid||seen.has(sid))throw Error('Every slide needs a unique id');seen.add(sid);
  const indices=new Set();
  slide.find('[data-step]').each((_,target)=>{
   const step=Number($(target).attr('data-step'));
   if(!Number.isInteger(step)||step<1)throw Error(`${sid}: invalid step`);
   indices.add(step);$(target).addClass('fragment').attr('data-fragment-index',step-1);
  });
  const steps=Math.max(0,...indices);
  if(indices.size!==steps)throw Error(`${sid}: reveal steps must be consecutive`);
  const template=slide.find('template.speaker-notes');
  const notes=[],reserve=[];
  const noteDOM=load(template.html()||'',null,false);
  noteDOM('[data-note-step]').each((_,p)=>{
   const step=Number(noteDOM(p).attr('data-note-step'));
   if(!Number.isInteger(step)||step<0||step>steps)throw Error(`${sid}: invalid note step`);
   notes.push({step,html:noteDOM.html(p)});
  });
  noteDOM('[data-reserve]').each((_,p)=>reserve.push(noteDOM.html(p)));
  for(let n=0;n<=steps;n++)if(!notes.some(note=>note.step===n))throw Error(`${sid}: missing speech for step ${n}`);
  // Every paragraph must be assigned, so migration cannot silently discard speech.
  function checkSpeech(nodes){for(const node of nodes){if(node.type==='text'&&node.data.trim()&&!noteDOM(node.parent).closest('[data-note-step],[data-reserve]').length)throw Error(`${sid}: unassigned speech`);if(node.children)checkSpeech(node.children);}}
  checkSpeech(noteDOM.root().contents().toArray());
  if(noteDOM('[data-note-step] [data-note-step],[data-note-step] [data-reserve],[data-reserve] [data-note-step],[data-reserve] [data-reserve]').length)throw Error(`${sid}: nested speech assignments`);
  const parent=slide.is('[data-optional]')?slide.attr('data-parent'):null;
  if(slide.is('[data-optional]')&&!parent)throw Error(`${sid}: optional slide needs parent`);
  slides.push({id:sid,title:slide.attr('aria-label')||slide.find('h1').text(),parent,steps,notes,reserve:reserve.join('\n')});
  template.remove();slide.removeClass('active').removeAttr('hidden');
 });
 if(!slides.length||!slides.some(s=>!s.parent))throw Error('At least one core slide required');
 for(const s of slides)if(s.parent&&!slides.some(p=>p.id===s.parent&&!p.parent))throw Error(`${s.id}: unknown or optional parent`);
 const temp=await mkdtemp(path.join(root,'.presentation-build-'));await mkdir(path.join(temp,'assets'));
 const protectedPaths=[sourcePath];
 try {
 const copied=new Map(),assetHashes=[];
 async function asset(reference,base,css=false) {
  if(reference.startsWith('data:')||reference.startsWith('#'))return reference;
  if(/^(https?:|\/\/)/.test(reference))throw Error(`External resource must be downloaded: ${reference}`);
  const clean=reference.split(/[?#]/)[0],suffix=reference.slice(clean.length),absolute=await realpath(path.resolve(base,decodeURIComponent(clean)));
  if(!inside(root,absolute))throw Error(`Resource outside project: ${reference}`);
  protectedPaths.push(absolute);
  if(copied.has(absolute))return (css?'':'assets/')+copied.get(absolute)+suffix;
  let bytes=await readFile(absolute);const filename=hash(bytes).slice(0,16)+path.extname(absolute);
  copied.set(absolute,filename);assetHashes.push(hash(bytes));
  if(path.extname(absolute)==='.css')bytes=Buffer.from(await cssText(bytes.toString(),path.dirname(absolute)));
  await writeFile(path.join(temp,'assets',filename),bytes);return (css?'':'assets/')+filename+suffix;
 }
 async function cssText(text,base){
  const urls=[...text.matchAll(/url\(\s*(['"]?)(.*?)\1\s*\)/g)];
  for(const match of urls)text=text.replace(match[0],`url("${await asset(match[2],base,true)}")`);
  if(/@import\s+['"]/.test(text))throw Error('Use linked local CSS instead of @import strings');
  return authoredCSS(text);
 }
 const styles=[];
 for(const el of $('head link[rel="stylesheet"], head style').toArray()){
  if(el.tagName==='link')styles.push(`<link rel="stylesheet" href="${await asset($(el).attr('href'),path.dirname(sourcePath))}">`);
  else styles.push(`<style>${await cssText($(el).html(),path.dirname(sourcePath))}</style>`);
 }
 for(const el of $('.sheet [src],dialog [src]').toArray())$(el).attr('src',await asset($(el).attr('src'),path.dirname(sourcePath)));
 for(const el of $('.sheet [srcset],dialog [srcset]').toArray())throw Error('Use separate local img sources; srcset is not yet supported');
 const runtimeFiles=[];
 for(const folder of ['src','tools'])for(const name of await readdir(path.join(toolkitRoot,folder),{recursive:true}))if(/\.(js|css)$/.test(name))runtimeFiles.push(path.join(folder,name));
 runtimeFiles.sort();
 const runtimeHashes=[];for(const name of runtimeFiles)runtimeHashes.push(hash(await readFile(path.join(toolkitRoot,name))));
 const buildId=hash(html+assetHashes.sort().join('|')+runtimeHashes.join('|')+await readFile(path.join(toolkitRoot,'package.json'),'utf8')).slice(0,20);
 const config={id:id||path.basename(root),title,buildId,width,height,slides};
 await writeFile(path.join(temp,'config.js'),'export default '+JSON.stringify(config,null,2)+';\n');
 await cp(path.join(toolkitRoot,'src/runtime'),path.join(temp,'runtime'),{recursive:true});
 await cp(path.join(toolkitRoot,'src/presenter'),path.join(temp,'presenter'),{recursive:true});
 const revealDir=path.dirname(require.resolve('reveal.js'));
 await mkdir(path.join(temp,'vendor'),{recursive:true});
 for(const name of ['reveal.mjs','reveal.css'])await cp(path.join(revealDir,name),path.join(temp,'vendor',name));
 await mkdir(path.join(temp,'licenses'),{recursive:true});
 await cp(path.join(revealDir,'../LICENSE'),path.join(temp,'licenses/reveal.txt'));
 for(const [i,licence] of licences.entries()){const source=await realpath(path.resolve(root,licence));if(!inside(root,source))throw Error('Licence outside project');protectedPaths.push(source);await cp(source,path.join(temp,'licenses',`${i}-${path.basename(source)}`));}
 const links=styles.join('\n');
 const head=`<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escape(title)}</title>`;
 const attrs=`lang="${escape($('html').attr('lang')||'ru')}" data-theme="${escape($('html').attr('data-theme')||'light')}" style="--page-width:${width}px;--page-height:${height}px"`;
 const sheets=$('.sheet').toArray().map(el=>$.html(el));
 const sections=sheets.map((sheet,i)=>`<section id="page-${escape(slides[i].id)}" data-slide-id="${escape(slides[i].id)}">${revealSheet(sheet)}</section>`).join('\n');
 const dialogs=$('dialog').toArray().map(el=>$.html(el)).join('\n');
 await writeFile(path.join(temp,'index.html'),`<!doctype html><html ${attrs}><head>${head}<link rel="stylesheet" href="vendor/reveal.css">${links}<link rel="stylesheet" href="runtime/runtime.css"></head><body><header id="toolbar"></header><main class="reveal"><div class="slides">${sections}</div></main>${dialogs}<script type="module" src="runtime/audience.js"></script></body></html>`);
 const readerPages=sheets.map((sheet,i)=>{const page=load(sheet,null,false);page('.sheet').addClass('active');const slide=slides[i];return `<div class="reader-page">${page.html()}<details class="reading-notes"><summary>Текст спикера · ${escape(slide.title)}</summary>${slide.notes.map(note=>note.html).join('')}${slide.reserve?'<h3>Резерв</h3>'+slide.reserve:''}</details></div>`;}).join('\n');
 const toc=slides.map(slide=>`<a href="#${escape(slide.id)}">${escape(slide.title)}${slide.parent?' · пример':''}</a>`).join('');
 await writeFile(path.join(temp,'reader.html'),`<!doctype html><html ${attrs}><head>${head}${links}<link rel="stylesheet" href="runtime/runtime.css"><style>html,body{height:auto;overflow:auto}.sheet{position:relative!important;transform:none!important;margin:24px auto;width:${width}px!important;height:${height}px!important}.fragment{opacity:1!important;visibility:visible!important;transform:none!important}.reading-toc,.reading-notes{max-width:${width}px;margin:24px auto;padding:24px;font:18px/1.5 system-ui}.reading-toc a{display:block;margin:8px 0;color:inherit}.reading-notes summary{cursor:pointer}@media print{@page{size:${width}px ${height}px;margin:0}.reading-toc,.reading-notes,dialog{display:none!important}.sheet{margin:0!important;break-after:page;break-inside:avoid}.reader-page:last-of-type .sheet{break-after:auto}}</style></head><body class="reader"><nav class="reading-toc" aria-label="Оглавление">${toc}</nav>${readerPages}${dialogs}<script type="module" src="runtime/reader.js"></script></body></html>`);
 await writeFile(path.join(temp,'presenter.html'),`<!doctype html><html lang="ru"><head>${head}<link rel="stylesheet" href="presenter/presenter.css"></head><body><main id="presenter"></main><script type="module" src="presenter/presenter.js"></script></body></html>`);
 const plain=fragment=>load(fragment).text().replace(/\s+/g,' ').trim();
 const notes=['# '+title];
 for(const slide of slides){notes.push(`\n## ${slide.title}${slide.parent?' (необязательный пример)':''}`);for(const note of slide.notes)notes.push(`\n### Шаг ${note.step}\n\n${plain(note.html)}`);if(slide.reserve)notes.push('\n### Резерв\n\n'+plain(slide.reserve));}
 await writeFile(path.join(temp,'speaker-notes.md'),notes.join('\n')+'\n');
 await writeFile(path.join(temp,'asset-manifest.json'),JSON.stringify({buildId,assets:[...copied.values()]},null,2));
 await outputBoundary({root,target:output,protectedPaths});
 await writeFile(path.join(temp,'.presentation-output.json'),JSON.stringify({generator:'werserk-presentation',buildId}));
 await rm(output,{recursive:true,force:true});await rename(temp,output);
 return {...config,assets:[...copied.values()]};
 }finally{await rm(temp,{recursive:true,force:true});}
}
