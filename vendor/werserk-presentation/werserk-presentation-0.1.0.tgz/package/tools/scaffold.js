import {access,mkdir,cp,writeFile,readFile,realpath,rename} from 'node:fs/promises';
import path from 'node:path';
import {toolkitRoot} from './build.js';
export async function scaffold(target,dependency) {
 if(!dependency)throw Error('Pass an exact reviewed dependency; local file linkage must be explicit');
 target=path.resolve(target);
 const parent=await realpath(path.dirname(target));target=path.join(parent,path.basename(target));
 if(target===toolkitRoot||target.startsWith(toolkitRoot+path.sep))throw Error('Presentation must be outside toolkit');
 try {await access(target);throw Error('Target already exists; refusing overwrite');}catch(e){if(e.code!=='ENOENT')throw e;}
 await mkdir(target);await cp(path.join(toolkitRoot,'templates/html'),target,{recursive:true});
 for(const file of ['gitignore','npmrc'])await rename(path.join(target,file),path.join(target,'.'+file));
 const manifest=JSON.parse(await readFile(path.join(toolkitRoot,'package.json'),'utf8'));
 await writeFile(path.join(target,'package.json'),JSON.stringify({name:path.basename(target),version:'0.1.0',private:true,type:'module',scripts:{dev:'werserk-presentation dev',build:'werserk-presentation build',check:'werserk-presentation check',export:'werserk-presentation export',pack:'werserk-presentation pack'},dependencies:{'werserk-presentation':dependency}},null,2)+'\n');
 return target;
}
