import {realpath,stat,readFile} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
export const toolkitRoot=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export const inside=(root,target)=>target.startsWith(root+path.sep);
const overlaps=(a,b)=>a===b||inside(a,b)||inside(b,a);
export async function canonicalTarget(target){
 const tail=[];let ancestor=path.resolve(target);
 for(;;){try{return path.join(await realpath(ancestor),...tail.reverse());}catch(e){if(e.code!=='ENOENT')throw e;tail.push(path.basename(ancestor));const parent=path.dirname(ancestor);if(parent===ancestor)throw e;ancestor=parent;}}
}
export async function outputBoundary({root,target,protectedPaths=[],kind='directory'}){
 root=await realpath(root);target=await canonicalTarget(target);
 const forbidden=[toolkitRoot,path.join(root,'node_modules'),path.join(root,'.git'),...protectedPaths];
 if(root===toolkitRoot||inside(toolkitRoot,root)||!inside(root,target)||forbidden.some(p=>overlaps(path.resolve(p),target)))throw Error('Output must be a separate derived path inside the external presentation project');
 let existing;try{existing=await stat(target);}catch(e){if(e.code!=='ENOENT')throw e;}
 if(existing){
  if(kind==='directory') {
   if(!existing.isDirectory())throw Error('Output collides with an existing file');
   let marker;try{marker=JSON.parse(await readFile(path.join(target,'.presentation-output.json'),'utf8'));}catch{}
   if(marker?.generator!=='werserk-presentation')throw Error('Refusing to replace a directory not owned by presentation build');
  } else {
   let marker;try{marker=JSON.parse(await readFile(target+'.presentation-output.json','utf8'));}catch{}
   const digest=existing.isFile()?createHash('sha256').update(await readFile(target)).digest('hex'):null;
   if(marker?.generator!=='werserk-presentation'||marker.sha256!==digest)throw Error('Refusing to replace an unowned or modified archive');
  }
 }
 return target;
}
