#!/usr/bin/env node
import {readFile} from 'node:fs/promises';
import path from 'node:path';
import {build} from './build.js';
import {scaffold} from './scaffold.js';
import {serve} from './server.js';
import {check,exportPDF,pack} from './output.js';
const [command,...args]=process.argv.slice(2);
async function options(){try{return JSON.parse(await readFile('presentation.config.json','utf8'));}catch(e){if(e.code==='ENOENT')return {};throw e;}}
try {
 if(command==='new') {if(!args[0])throw Error('Usage: werserk-presentation new ../external-project [pinned dependency]');console.log(await scaffold(args[0],args[1]));}
 else {
  const opts=await options(),out=path.resolve(opts.out||'dist');
  switch(command) {
   case 'build': {const result=await build(opts);console.log(JSON.stringify({id:result.id,buildId:result.buildId,slides:result.slides.length,core:result.slides.filter(s=>!s.parent).length,resources:result.assets.length}));break;}
   case 'dev': {
    await build(opts);const running=await serve(out,Number(args[0]||4173));console.log(running.url+' — audience; /presenter.html uses the audience session; /reader.html full reading');
    for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>running.server.close(()=>process.exit(0)));
    break;
   }
   case 'check':console.log(JSON.stringify(await check(out,{browser:args.includes('--browser')})));break;
   case 'export':console.log(await exportPDF(out,process.cwd()));break;
   case 'pack':console.log(await pack(out,path.resolve(args[0]||'presentation-offline.tar.gz'),process.cwd()));break;
   default:console.log('werserk-presentation new TARGET [DEPENDENCY] | build | dev [PORT] | check [--browser] | export | pack [ARCHIVE]');if(command)process.exitCode=1;
  }
 }
}catch(error){console.error(error.message);process.exitCode=1;}
