import config from '../config.js';
import {wireInteractions} from '../runtime/interactions.js';
import {channelName,ensureSession,pointerPosition,validSnapshot} from '../runtime/session.js';
const session=ensureSession(),channel=new BroadcastChannel(channelName(config,session));
const root=document.querySelector('#presenter') || document.body;
root.innerHTML='<header><strong id="deck-title"></strong><span id="connection" role="status">Ожидание окна аудитории</span><a id="audience-link" target="_blank">Открыть показ</a></header><nav><button data-command="previousSlide">Предыдущий слайд</button><button data-command="back">← Шаг</button><button data-command="next">Шаг →</button><button data-command="nextSlide">Следующий слайд</button><select id="presenter-picker" aria-label="Выбрать слайд"></select><button data-command="return">Вернуться</button><button data-command="continue">Продолжить</button><button data-command="closeFigure" hidden>Закрыть рисунок · Esc</button><button id="pointer-toggle" aria-pressed="false">Указка</button></nav><div class="previews"><div><h2>Текущий слайд</h2><iframe id="current-preview" title="Превью текущего слайда"></iframe></div><div><h2>Следующий основной слайд</h2><iframe id="next-preview" title="Превью следующего основного слайда"></iframe></div></div><div class="presenter-lower"><section id="speech"><h2 id="slide-title"></h2><p id="step-status"></p><div id="step-notes"></div><details id="full-script"><summary>Полный текст слайда</summary><div></div></details><details id="reserve"><summary>Резерв</summary><div></div></details></section><aside><output id="timer">00:00</output><button id="timer-start">Запустить таймер</button><button id="timer-reset">Сбросить таймер</button><p>Стрелки — шаг. Переход к слайду начинает его с шага 0.</p></aside></div>';
root.querySelector('#deck-title').textContent=config.title;
const audienceURL=new URL('index.html',location.href);audienceURL.searchParams.set('session',session);
root.querySelector('#audience-link').href=audienceURL;
for(const [id,preview] of [['current-preview','1'],['next-preview','next']]){const url=new URL(audienceURL);url.searchParams.set('preview',preview);root.querySelector(`#${id}`).src=url;}
const picker=root.querySelector('#presenter-picker');
for(const slide of config.slides){const option=document.createElement('option');option.value=slide.id;option.textContent=`${slide.parent?'↳ ':''}${slide.title}`;picker.append(option);}
let confirmed=null,lastSeen=0,pointerEnabled=false,currentPoint=null,elapsed=0,timerStart=null;
function send(command,target){if(Date.now()-lastSeen<2000)channel.postMessage({type:'command',command,target});}
function pointer(point=null){currentPoint=point;channel.postMessage({type:'pointer',id:confirmed?.id,point});}
root.addEventListener('click',event=>{const button=event.target.closest('[data-command]');if(button)send(button.dataset.command);});
picker.addEventListener('change',()=>send('goto',picker.value));
wireInteractions(document,{slides:config.slides,state:()=>confirmed,command:send});
root.querySelector('#pointer-toggle').onclick=event=>{pointerEnabled=!pointerEnabled;event.currentTarget.setAttribute('aria-pressed',String(pointerEnabled));pointer();};
const preview=root.querySelector('#current-preview');
preview.addEventListener('load',()=>{
 const doc=preview.contentDocument;
 let previewOpener=null,lastModal=null;
 const transport=(name,target,opener)=>{if(name==='openFigure')previewOpener=opener;send(name,target);};
 wireInteractions(doc,{slides:config.slides,state:()=>confirmed,command:transport});
 // A confirmed modal close restores focus to the authored preview trigger.
 const observer=new MutationObserver(()=>{
  const modal=doc.querySelector('dialog[open]')?.id || null;
  if(lastModal && !modal)previewOpener?.focus();lastModal=modal;
 });
 observer.observe(doc.body,{subtree:true,attributes:true,attributeFilter:['open']});
 doc.addEventListener('pointermove',event=>{
  if(!pointerEnabled || confirmed?.modal || Date.now()-lastSeen>=2000)return;
  const sheet=doc.querySelector('.slides>section.present .sheet');
  pointer(sheet?pointerPosition(event.clientX,event.clientY,sheet.getBoundingClientRect()):null);
 });
 doc.documentElement.addEventListener('pointerleave',()=>pointer());
});
root.querySelector('#timer-start').onclick=event=>{
 if(timerStart!==null){elapsed+=Date.now()-timerStart;timerStart=null;event.currentTarget.textContent='Запустить таймер';}
 else{timerStart=Date.now();event.currentTarget.textContent='Остановить таймер';}
};
root.querySelector('#timer-reset').onclick=()=>{elapsed=0;timerStart=null;root.querySelector('#timer-start').textContent='Запустить таймер';};
function render(snapshot){
 const slide=config.slides.find(s=>s.id===snapshot.id);
 const core=config.slides.filter(s=>!s.parent);
 const hasNext=core.findIndex(s=>s.id===(slide.parent || slide.id))<core.length-1;
 const next=root.querySelector('#next-preview');next.hidden=!hasNext;next.previousElementSibling.textContent=hasNext?'Следующий основной слайд':'Конец доклада';
 picker.value=slide.id;root.querySelector('#slide-title').textContent=slide.title;root.querySelector('#step-status').textContent=`Шаг ${snapshot.step} / ${slide.steps}`;
 const notes=root.querySelector('#step-notes');
 if(notes.dataset.slideId!==slide.id||notes.dataset.noteStep!==String(snapshot.step)){
 notes.dataset.slideId=slide.id;notes.dataset.noteStep=snapshot.step;notes.replaceChildren();
 const article=document.createElement('article');article.innerHTML=slide.notes.filter(note=>note.step===snapshot.step).map(note=>note.html).join('\n');article.dataset.noteStep=snapshot.step;article.dataset.noteCurrent='';article.setAttribute('aria-current','step');notes.append(article);notes.scrollTop=0;
 root.querySelector('#full-script>div').innerHTML=slide.notes.map(note=>note.html).join('\n');
 root.querySelector('#reserve>div').innerHTML=slide.reserve;
 }
 root.querySelector('[data-command="return"]').disabled=!slide.parent;
 root.querySelector('[data-command="closeFigure"]').hidden=!snapshot.modal;
}
channel.onmessage=({data})=>{
 if(data?.type!=='state' || !validSnapshot(config,data.state))return;
 const changed=confirmed && (confirmed.id!==data.state.id || confirmed.step!==data.state.step || confirmed.modal!==data.state.modal);
 lastSeen=Date.now();if(changed)pointer();
 confirmed=data.state;root.querySelector('#connection').textContent='Связь с показом установлена';
 document.documentElement.dataset.theme=data.theme;
 if(changed || !root.querySelector('[data-note-current]'))render(confirmed);
};
const heartbeat=setInterval(()=>{
 const connected=Date.now()-lastSeen<2000;
 if(!connected){root.querySelector('#connection').textContent='С окном аудитории нет связи — откройте или обновите показ';pointer();}
 else if(pointerEnabled && currentPoint && !confirmed?.modal)pointer(currentPoint);
 for(const button of root.querySelectorAll('[data-command]'))button.disabled=!connected || (!!confirmed?.modal && button.dataset.command!=='closeFigure') || (button.dataset.command==='return' && !config.slides.find(s=>s.id===confirmed?.id)?.parent);
 const seconds=Math.floor((elapsed+(timerStart===null?0:Date.now()-timerStart))/1000);
 root.querySelector('#timer').textContent=`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;
 channel.postMessage({type:'request'});
},500);
window.presenter={state:()=>confirmed,send,session};
channel.postMessage({type:'request'});
addEventListener('pagehide',()=>{clearInterval(heartbeat);pointer();channel.close();});
