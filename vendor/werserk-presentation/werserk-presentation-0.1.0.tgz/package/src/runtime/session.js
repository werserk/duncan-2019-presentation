export const channelName=(config,session)=>`werserk-presentation:${encodeURIComponent(config.id)}:${encodeURIComponent(config.buildId)}:${encodeURIComponent(session)}`;
export const storageKey=(config,session)=>`${channelName(config,session)}:state`;
export function validSnapshot(config,state) {
 if(!state || !Number.isInteger(state.step)) return false;
 const slide=config.slides.find(s=>s.id===state.id);
 if(!slide || state.step<0 || state.step>slide.steps) return false;
 if(state.returnTo) {
  const parent=config.slides.find(s=>s.id===slide.parent);
  if(!parent || state.returnTo.id!==parent.id || !Number.isInteger(state.returnTo.step) || state.returnTo.step<0 || state.returnTo.step>parent.steps) return false;
 }
 return true;
}
export function pointerPosition(clientX,clientY,rect) {
 if(rect.width<=0 || rect.height<=0) return null;
 const x=(clientX-rect.left)/rect.width,y=(clientY-rect.top)/rect.height;
 return x>=0 && x<=1 && y>=0 && y<=1?{x,y}:null;
}
export function ensureSession() {
 const url=new URL(location.href);
 let session=url.searchParams.get('session');
 if(!session){session=crypto.randomUUID();url.searchParams.set('session',session);history.replaceState(null,'',url);}
 return session;
}
