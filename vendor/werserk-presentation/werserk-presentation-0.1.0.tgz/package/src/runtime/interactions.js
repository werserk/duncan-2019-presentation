// Authored controls and neutral gestures share the same command transport.
export function linkCommand(slides,state,id){
 const target=slides.find(s=>s.id===id),current=slides.find(s=>s.id===state?.id);
 if(!target || !current)return null;
 if(target.parent)return {command:'optional',target:id};
 if(current.parent===id)return {command:'return'};
 const core=slides.filter(s=>!s.parent),position=core.findIndex(s=>s.id===(current.parent || current.id));
 return core[position+1]?.id===id?{command:'continue'}:{command:'goto',target:id};
}
export function wireInteractions(doc,{slides,state,command}){
 doc.addEventListener('click',event=>{
  const target=event.target.closest?.('*');
  if(!target)return;
  // Reveal installs its own hash-link listener even when hash:false.
  if(target.closest('a[href^="#"]')){event.preventDefault();event.stopPropagation();}
  if(event.button!==0 || target.closest('[inert],[hidden],.fragment:not(.visible)'))return;
  const close=target.closest('.figure-close,#figure-close');
  if(close){event.preventDefault();event.stopPropagation();command('closeFigure');return;}
  const open=target.closest('.figure-open');
  if(open){event.preventDefault();event.stopPropagation();command('openFigure',open.dataset.figure || 'figure-dialog',open);return;}
  const anchor=target.closest('a[href^="#"]');
  if(anchor){event.preventDefault();event.stopPropagation();const action=linkCommand(slides,state(),anchor.hash.slice(1));if(action){event.preventDefault();command(action.command,action.target);}return;}
  if(target.closest('.sheet.active') && !target.closest('a,button,input,select,textarea,dialog,[contenteditable]') && !doc.getSelection()?.toString()){event.stopPropagation();command('next');}
 },true);
 doc.addEventListener('keydown',event=>{
  if(event.altKey || event.ctrlKey || event.metaKey)return;
  if(event.key==='Escape'){if(state()?.modal){event.preventDefault();command('closeFigure');}return;}
  if(event.target.closest?.('input,textarea,select,[contenteditable]') || (event.key===' ' && event.target.closest?.('button,a')))return;
  const name={ArrowRight:'next',ArrowDown:'next',PageDown:'next',' ':'next',ArrowLeft:'back',ArrowUp:'back',PageUp:'back',Home:'first'}[event.key];
  if(name){event.preventDefault();command(name==='first'?'goto':name,name==='first'?slides[0].id:undefined);}
 });
}
