// Reading controls deliberately have no Reveal/navigation authority.
const openers=new WeakMap();
for(const trigger of document.querySelectorAll('.figure-open')){
 const dialog=document.getElementById(trigger.dataset.figure||'figure-dialog');
 if(!dialog)continue;
 if(!openers.has(dialog)){openers.set(dialog,null);dialog.addEventListener('close',()=>openers.get(dialog)?.focus());}
 trigger.addEventListener('click',()=>{openers.set(dialog,trigger);dialog.showModal();});
}
for(const button of document.querySelectorAll('.figure-close,#figure-close'))button.addEventListener('click',()=>button.closest('dialog').close());
