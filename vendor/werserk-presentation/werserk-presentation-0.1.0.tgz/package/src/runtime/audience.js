import Reveal from '../vendor/reveal.mjs';
import config from '../config.js';
import {routeCommand,corePosition} from './navigation.js';
import {wireInteractions} from './interactions.js';
import {channelName,storageKey,validSnapshot,ensureSession} from './session.js';

const params=new URL(location.href).searchParams, preview=params.get('preview');
const session=ensureSession(), channel=new BroadcastChannel(channelName(config,session));
const reveal=new Reveal(document.querySelector('.reveal'),{
 width:config.width,height:config.height,margin:0,controls:false,progress:false,slideNumber:false,
 keyboard:false,touch:false,hash:false,history:false,overview:false,transition:'none',backgroundTransition:'none',
 embedded:!!preview,autoSlide:0,center:false,disableLayout:false,scrollActivationWidth:0
});
let returnTo=null,applying=false,pointerTimeout,heartbeat,ready=false;
const figureOpeners=new WeakMap();
const pointer=document.createElement('div');pointer.className='presentation-pointer';pointer.hidden=true;document.body.append(pointer);
function state(){
 const native=reveal.getState(),slide=config.slides[native.indexh] || config.slides[0];
 return {id:slide.id,step:Math.max(0,(native.indexf ?? -1)+1),returnTo,modal:document.querySelector('dialog[open]')?.id || null};
}
function hidePointer(){pointer.hidden=true;clearTimeout(pointerTimeout);}
function apply(target){
 if(!validSnapshot(config,target)) return;
 applying=true;returnTo=target.returnTo || null;hidePointer();
 reveal.slide(config.slides.findIndex(s=>s.id===target.id),0,target.step-1);
 applying=false;render();
}
function publish(){
 if(preview || !ready) return;
 const snapshot=state();
 try {localStorage.setItem(storageKey(config,session),JSON.stringify(snapshot));}catch{}
 channel.postMessage({type:'state',state:snapshot,theme:document.documentElement.dataset.theme || 'dark'});
}
function command(name,target,opener){
 if(preview || !ready)return false;
 const opened=document.querySelector('dialog[open]');
 if(name==='closeFigure'){opened?.close();publish();return !!opened;}
 if(name==='openFigure'){
  if(opened)return false;
  const dialog=document.getElementById(target);
  if(!(dialog instanceof HTMLDialogElement))return false;
  const source=opener || [...reveal.getCurrentSlide().querySelectorAll('.figure-open')].find(el=>(el.dataset.figure || 'figure-dialog')===target);
  if(!source || source.closest('[inert],.fragment:not(.visible)'))return false;
  figureOpeners.set(dialog,source);hidePointer();dialog.showModal();publish();return true;
 }
 if(opened)return false;
 if(name==='reset') {const url=new URL(location.href);url.searchParams.set('session',crypto.randomUUID());url.hash='';location.replace(url);return true;}
 apply(routeCommand(config.slides,state(),name,target));publish();return true;
}
const toolbar=document.querySelector('#toolbar');
if(toolbar && !preview){
 toolbar.innerHTML='<button type="button" data-command="back" aria-label="Предыдущий шаг">←</button><span id="core-counter"></span><button type="button" data-command="next" aria-label="Следующий шаг">→</button><select id="slide-picker" aria-label="Выбрать слайд"></select><button id="theme-toggle" type="button">Тема</button><button id="fullscreen" type="button">Полный экран</button><button id="presenter-open" type="button">Спикер</button><button type="button" data-command="reset">Новый показ</button><div id="core-progress"></div>';
 for(const id of ['core-counter','core-progress'])document.body.append(toolbar.querySelector(`#${id}`));
 const select=toolbar.querySelector('select');
 for(const slide of config.slides){const option=document.createElement('option');option.value=slide.id;option.textContent=`${slide.parent?'↳ ':''}${slide.title}`;select.append(option);}
 select.addEventListener('change',()=>command('goto',select.value));
 toolbar.addEventListener('click',event=>{const button=event.target.closest('[data-command]');if(button)command(button.dataset.command);});
 toolbar.querySelector('#theme-toggle').onclick=()=>{document.documentElement.dataset.theme=document.documentElement.dataset.theme==='light'?'dark':'light';publish();};
 toolbar.querySelector('#fullscreen').onclick=()=>document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen();
 toolbar.querySelector('#presenter-open').onclick=()=>{const url=new URL('presenter.html',location.href);url.searchParams.set('session',session);window.open(url,'_blank');};
}
function render(){
 const snapshot=state(),position=corePosition(config.slides,snapshot.id);
 for(const section of document.querySelectorAll('.slides>section')){
  const active=section.dataset.slideId===snapshot.id;
  section.querySelector('.sheet')?.classList.toggle('active',active);
  for(const fragment of section.querySelectorAll('.fragment')) fragment.inert=!active || !fragment.classList.contains('visible');
 }
 if(toolbar && !preview){
  document.querySelector('#core-counter').textContent=`${String(position.index).padStart(2,'0')} / ${position.total}`;
  document.querySelector('#core-progress').style.width=`${position.progress*100}%`;
  toolbar.querySelector('select').value=snapshot.id;
 }
}
await reveal.initialize();ready=true;
for(const event of ['slidechanged','fragmentshown','fragmenthidden']) reveal.on(event,()=>{if(!applying){hidePointer();render();publish();}});
if(preview){
 document.body.classList.add('presentation-preview');
 if(toolbar) toolbar.hidden=true;
 document.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();},true);
}else{
 let initial;
 try{initial=JSON.parse(localStorage.getItem(storageKey(config,session)));}catch{}
 if(!validSnapshot(config,initial)){
  const id=decodeURIComponent(location.hash.replace(/^#\/?(?:page-)?/,''));
  initial={id:config.slides.some(s=>s.id===id)?id:config.slides[0].id,step:0};
 }
 apply(initial);
 wireInteractions(document,{slides:config.slides,state,command});
 for(const dialog of document.querySelectorAll('dialog')){
  dialog.addEventListener('close',()=>{figureOpeners.get(dialog)?.focus();publish();});
 }

}
channel.onmessage=({data})=>{
 if(!data || !ready)return;
 if(preview){
  if(data.type==='state' && validSnapshot(config,data.state)){
   const target=preview==='next'?routeCommand(config.slides,data.state,'nextSlide'):data.state;
   apply(target);document.documentElement.dataset.theme=data.theme;
   for(const dialog of document.querySelectorAll('dialog')){
    const open=preview==='1' && dialog.id===data.state.modal;
    if(open)dialog.setAttribute('open','');else dialog.removeAttribute('open');
   }
  }
  return;
 }
 if(data.type==='request')publish();
 if(data.type==='command')command(data.command,data.target);
 if(data.type==='pointer'){
  const point=data.point;
  if(!point || data.id!==state().id || document.querySelector('dialog[open]') || !Number.isFinite(point.x) || !Number.isFinite(point.y) || point.x<0 || point.x>1 || point.y<0 || point.y>1){hidePointer();return;}
  const rect=reveal.getCurrentSlide().querySelector('.sheet').getBoundingClientRect();
  pointer.style.left=`${rect.left+point.x*rect.width}px`;pointer.style.top=`${rect.top+point.y*rect.height}px`;pointer.hidden=false;
  clearTimeout(pointerTimeout);pointerTimeout=setTimeout(hidePointer,1000);
 }
};
window.presentation={command,state,reveal,session,preview:!!preview};
render();
if(preview)channel.postMessage({type:'request'});else {publish();heartbeat=setInterval(publish,500);}
addEventListener('pagehide',()=>{clearInterval(heartbeat);hidePointer();channel.close();});
