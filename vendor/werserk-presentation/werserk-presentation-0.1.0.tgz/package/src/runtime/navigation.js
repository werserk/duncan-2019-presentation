// Route policy produces targets; the caller always reads the confirmed Reveal state.
export function corePosition(slides, id) {
 const core=slides.filter(s=>!s.parent), slide=slides.find(s=>s.id===id);
 const index=core.findIndex(s=>s.id===(slide?.parent || id))+1;
 return {index,total:core.length,progress:index/core.length};
}
export function routeCommand(slides, state, command, target) {
 const current=slides.find(s=>s.id===state.id), core=slides.filter(s=>!s.parent);
 if(!current) return state;
 const position=core.findIndex(s=>s.id===(current.parent || current.id));
 const to=(slide,step=0,returnTo=null)=>slide?{id:slide.id,step,returnTo}:state;
 const parent=slides.find(s=>s.id===current.parent);
 const restore=()=>to(parent,state.returnTo?.id===parent?.id?state.returnTo.step:parent?.steps);
 switch(command) {
 case 'next': return state.step<current.steps?to(current,state.step+1,state.returnTo):to(core[position+1]);
 case 'back': return state.step>0?to(current,state.step-1,state.returnTo):current.parent?restore():to(core[position-1],core[position-1]?.steps);
 case 'return': return current.parent?restore():state;
 case 'continue': case 'nextSlide': return to(core[position+1]);
 case 'previousSlide': return to(core[position-1]);
 case 'goto': return to(slides.find(s=>s.id===target));
 case 'optional': {
  const optional=slides.find(s=>s.id===target && s.parent);
  return to(optional,0,optional?.parent===state.id?{id:state.id,step:state.step}:null);
 }
 default:return state;
 }
}
