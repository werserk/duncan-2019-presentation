# Third-party resources

Reveal.js is pinned in package.json and package-lock.json, MIT, Copyright Hakim El Hattab. Its licence is copied from the installed package into generated dist/licenses/reveal.txt. npm dependency licences remain in their installed packages. No scientific figures or real decks are included in this toolkit.

A consuming presentation owns licences for its fonts, images and content; declare local licence files in presentation.config.json as a licences array to include them in the offline package.

PostCSS and postcss-selector-parser are MIT-licensed build dependencies installed through npm; they parse author CSS without changing runtime/vendor rules. Their npm packages retain their licence notices; they are not needed in the delivered offline viewer.
